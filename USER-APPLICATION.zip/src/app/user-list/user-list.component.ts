import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddUserComponent } from '../add-user/add-user.component';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {
   userListArray = [{
   fullName: 'Richard Lovelace',
   DOB: new Date(),
   languages: ['Spanish', 'Latin'],
   gender: 'Male',
   about: 'dhjkhd'
},
{
   fullName: 'Richard Lovelace',
   DOB: new Date(),
   languages: ['Spanish', 'Latin'],
   gender: 'Male',
   about: 'dhjkhd'
},]
  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }

  openDialog() {
   this.dialog.open(AddUserComponent);
 }

}
